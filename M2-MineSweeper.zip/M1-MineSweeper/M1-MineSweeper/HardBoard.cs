﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone2- Minesweeper
 * */

namespace M1_MineSweeper
{
    class HardBoard : Board
    {
        public HardBoard() : base()
        {
            Title = "Hard";
            Horizontal = 16;
            Vertical = 30;
            TwoDigitYAxis = true;
            TwoDigitXAxis = true;
            TotalMines = 99;
            CreateEmptyCellArray();
        }
    }
}
