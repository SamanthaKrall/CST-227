﻿namespace Minesweeper
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.remainingFlags = new System.Windows.Forms.Label();
            this.Play = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.difficultyCB = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // remainingFlags
            // 
            this.remainingFlags.AutoSize = true;
            this.remainingFlags.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.remainingFlags.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.remainingFlags.ForeColor = System.Drawing.Color.Red;
            this.remainingFlags.Location = new System.Drawing.Point(330, 405);
            this.remainingFlags.Name = "remainingFlags";
            this.remainingFlags.Size = new System.Drawing.Size(67, 27);
            this.remainingFlags.TabIndex = 1;
            this.remainingFlags.Text = "Flags";
            // 
            // Play
            // 
            this.Play.Location = new System.Drawing.Point(422, 14);
            this.Play.Name = "Play";
            this.Play.Size = new System.Drawing.Size(237, 35);
            this.Play.TabIndex = 3;
            this.Play.Text = "&Play";
            this.Play.UseVisualStyleBackColor = true;
            this.Play.Click += new System.EventHandler(this.Play_Click);
            // 
            // difficultyCB
            // 
            this.difficultyCB.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.difficultyCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.difficultyCB.FormattingEnabled = true;
            this.difficultyCB.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.difficultyCB.Location = new System.Drawing.Point(99, 16);
            this.difficultyCB.Name = "difficultyCB";
            this.difficultyCB.Size = new System.Drawing.Size(204, 33);
            this.difficultyCB.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(761, 452);
            this.Controls.Add(this.difficultyCB);
            this.Controls.Add(this.Play);
            this.Controls.Add(this.remainingFlags);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Minesweeper";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label remainingFlags;
        private System.Windows.Forms.Button Play;
        private System.Windows.Forms.Timer timer;
        public System.Windows.Forms.ComboBox difficultyCB;
    }
}

