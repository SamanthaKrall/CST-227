﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Author: Samantha Krall
// CST-227
// 2018

namespace Minesweeper
{
    public class PlayerStats : IComparable<PlayerStats>
    {
        public string Initials { get; set; }
        public string Difficulty { get; set; }
        public TimeSpan time { get; set; }

        public PlayerStats(string Initials, string Difficulty, TimeSpan time)
        {
            this.Initials = Initials;
            this.Difficulty = Difficulty;
            this.time = time;
        }
        public int CompareTo(PlayerStats other)
        {
            return time.CompareTo(other.time);
        }
    }
}
