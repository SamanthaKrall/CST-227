﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Author: Samantha Krall
// CST-227
// 2018

namespace Minesweeper
{
    public partial class Form1 : Form
    {
        Button[,] button = new Button[31, 31];
        int[,] buttonProp = new int[31, 31];
        int[,] savedButtonProp = new int[31, 31];
        Point coord;
        bool firstPlay = true;
        bool gameOver = false;
        int seconds = 0;
        int minutes = 0;
        int[] dX8 = { 1, 0, -1, 0, 1, -1, -1, 1 };
        int[] dY8 = { 0, 1, 0, -1, 1, -1, 1, -1 };
        int startX;
        int startY;
        int flagValue = 10;
        int flags;
        int buttonSize = 20;
        int distanceBetween = 20;
        int width; 
        int height;
        int mines;
        int difficulty;

        public int GetDifficulty()
        {
            switch (difficultyCB.Text)
            {
                case "Easy":
                    difficulty = 1;
                    break;
                case "Medium":
                    difficulty = 2;
                    break;
                case "Hard":
                    difficulty = 3;
                    break;
            }
            return difficulty;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        void SetButtonImage(int x, int y)
        {
            button[x, y].Enabled = false;
            button[x, y].BackgroundImageLayout = ImageLayout.Stretch;
            if (gameOver && buttonProp[x, y] == flagValue)
            {
                buttonProp[x, y] = savedButtonProp[x, y];
            }
            if (gameOver)
            {
                timer.Stop();
                timer.Dispose();
            }
            switch (buttonProp[x, y])
            {
                case 0:
                    button[x, y].BackgroundImage = Properties.Resources.blank1;
                    EmptySpace(x, y);
                    break;
                case 1:
                    button[x, y].BackgroundImage = Properties.Resources._1;
                    break;
                case 2:
                    button[x, y].BackgroundImage = Properties.Resources._2;
                    break;
                case 3:
                    button[x, y].BackgroundImage = Properties.Resources._3;
                    break;
                case 4:
                    button[x, y].BackgroundImage = Properties.Resources._4;
                    break;
                case 5:
                    button[x, y].BackgroundImage = Properties.Resources._5;
                    break;
                case 6:
                    button[x, y].BackgroundImage = Properties.Resources._6;
                    break;
                case 7:
                    button[x, y].BackgroundImage = Properties.Resources._7;
                    break;
                case 8:
                    button[x, y].BackgroundImage = Properties.Resources._8;
                    break;
                case -1:
                    button[x, y].BackgroundImage = Properties.Resources.mine1;
                    if (!gameOver)
                    {
                        GameOver();
                    }
                    break;
            }
        }
        int IsPointOnMap(int x, int y)
        {
            if (x < 1 || x > width || y < 1 || y > height)
            {
                return 0;
            }
            return 1;
        }
        void EmptySpace(int x, int y)
        {
            if (buttonProp[x, y] == 0)
            {
                for (int i = 0; i < 8; i++)
                {
                    int cx = x + dX8[i];
                    int cy = y + dY8[i];
                    if (IsPointOnMap(cx, cy) == 1)
                    {
                        if(button[cx,cy].Enabled == true && buttonProp[cx,cy] != -1 && !gameOver)
                        {
                            SetButtonImage(cx, cy);
                        }
                    }
                }
            }
        }
        void DiscoverMap()
        {
            for (int i = 1; i <= width; i++)
            {
                for (int j = 1; j <= height; j++)
                {
                    if (button[i, j].Enabled == true)
                    {
                        SetButtonImage(i, j);
                    }
                }
            }
        }
        void GameOver()
        {
            GetDifficulty();
            int time = (minutes * 60) + seconds;
            bool win = false;
            gameOver = true;
            DiscoverMap();
            HighScoreForm highScore = new HighScoreForm(difficulty, time , win);
            highScore.ShowDialog();
            //MessageBox.Show("Game Over \nTime Elapsed: " + minutes + " minutes and " + seconds + " seconds");
        }
        void CheckFlagWin()
        {
            bool win = true;
            for (int i = 1; i <= width; i++)
            {
                for (int j = 1; j <= height; j++)
                {
                    if (buttonProp[i, j] == -1)
                    {
                        win = false;
                    }
                }
            }
            if (win)
            {
                WinGame();
            }
        }
        void WinGame()
        {
            GetDifficulty();
            int time = (minutes * 60) + seconds;
            bool win = true;
            gameOver = true;
            DiscoverMap();
            HighScoreForm highScore = new HighScoreForm(difficulty, time, win);
            highScore.ShowDialog();
            //MessageBox.Show("You Won! \nTime Elapsed: " + minutes + " minutes and " + seconds + " seconds");
        }
        void CheckClickWin()
        {
            bool win = true;
            for (int i = 1; i <= width; i++)
            {
                for (int j = 1; j <= height; j++)
                {
                    if (button[i, j].Enabled == true && savedButtonProp[i, j] != -1)
                    {
                        win = false;
                    }
                }
            }
            if (win)
            {
                WinGame();
            }
        }
        private void OneClick(object sender, EventArgs e)
        {
            coord = ((Button)sender).Location;
            int x = (coord.X - startX) / buttonSize;
            int y = (coord.Y - startY) / buttonSize;
            if (buttonProp[x, y] != flagValue)
            {
                ((Button)sender).Enabled = false;
                ((Button)sender).Text = "";
                ((Button)sender).BackgroundImageLayout = ImageLayout.Stretch;
                if (buttonProp[x, y] != -1 && !gameOver)
                {
                    CheckClickWin();
                }
                SetButtonImage(x, y);
            }
        }
        int MinesAround(int x, int y)
        {
            int score = 0;
            for (int i = 0; i < 8; i++)
            {
                int cx = x + dX8[i];
                int cy = y + dY8[i];
                if (IsPointOnMap(cx, cy) == 1 && buttonProp[cx, cy] == -1)
                {
                    score++;
                }
            }
            return score;
        }
        void SetMapNumbers(int x, int y)
        {
            for (int i = 1; i <= x; i++)
            {
                for (int j = 1; j <= y; j++)
                {
                    if (buttonProp[i, j] != -1)
                    {
                        buttonProp[i, j] = MinesAround(i, j);
                        savedButtonProp[i, j] = MinesAround(i, j);
                    }
                }
            }
        }
        private void RightClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                coord = ((Button)sender).Location;
                int x = (coord.X - startX) / buttonSize;
                int y = (coord.Y - startY) / buttonSize;
                if (buttonProp[x, y] != flagValue && flags > 0)
                {
                    button[x, y].BackgroundImageLayout = ImageLayout.Stretch;
                    button[x, y].BackgroundImage = Properties.Resources.flag;
                    buttonProp[x, y] = flagValue;
                    flags--;
                    CheckFlagWin();
                }
                else
                {
                    if (buttonProp[x, y] == flagValue)
                    {
                        buttonProp[x, y] = savedButtonProp[x, y];
                        button[x, y].BackgroundImageLayout = ImageLayout.Stretch;
                        button[x, y].BackgroundImage = null;
                        flags++;
                    }
                }
                remainingFlags.Text = "Flags: " + flags;
            }
        }
        void CreateButtons(int x, int y)
        {
            for (int i = 1; i <= x; i++)
            {
                for (int j = 1; j <= y; j++)
                {
                    button[i, j] = new Button();
                    button[i, j].SetBounds(i * buttonSize + startX, j * buttonSize + startY, distanceBetween, distanceBetween);
                    button[i, j].Click += new EventHandler(OneClick);
                    button[i, j].MouseUp += new MouseEventHandler(RightClick);
                    buttonProp[i, j] = 0;
                    savedButtonProp[i, j] = 0;
                    button[i, j].TabStop = false;
                    Controls.Add(button[i, j]);
                }
            }
        }
        void GenerateMap(int x, int y, int mines)
        {
            Random rand = new Random();
            List<int> coordX = new List<int>();
            List<int> coordY = new List<int>();
            while (mines > 0)
            {
                coordX.Clear();
                coordY.Clear();
                for (int i = 1; i <= x; i++)
                {
                    for (int j = 1; j <= y; j++)
                    {
                        if (buttonProp[i, j] != -1)
                        {
                            coordX.Add(i);
                            coordY.Add(j);
                        }
                    }
                }
                int randNum = rand.Next(0, coordX.Count);
                buttonProp[coordX[randNum], coordY[randNum]] = -1;
                savedButtonProp[coordX[randNum], coordY[randNum]] = -1;
                mines--;
            }
        }
        
        void StartGame()
        {
            flags = mines;
            gameOver = false;
            timer.Start();
            minutes = 0;
            seconds = 0;
            remainingFlags.Text = "Flags: " + flags;
            score.Text = "Score: " + 0;
            if (firstPlay)
            {
                CreateButtons(width, height);
            }
            GenerateMap(width, height, mines);
            SetMapNumbers(width, height);
        }
        void ResetGame(int x, int y)
        {
            for (int i = 1; i <= x; i++)
            {
                for (int j = 1; j <= y; j++)
                {
                    button[i, j].Enabled = true;
                    button[i, j].Text = "";
                    button[i, j].BackgroundImage = null;
                    buttonProp[i, j] = 0;
                    savedButtonProp[i, j] = 0;
                }
            }
        }
        void TableMargins(int x, int y)
        {
            startX = (this.Size.Width - (width + 2) * distanceBetween) / 2;
            startY = (this.Size.Height - (height + 2) * distanceBetween) / 2;
        }
       
        private void Score_Click(object sender, EventArgs e)
        {

        }

        private void RemainingFlags_Click(object sender, EventArgs e)
        {

        }

        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void Difficulty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Play_Click(object sender, EventArgs e)
        {
            switch (difficultyCB.Text)
            {
                case "Easy":
                    mines = 10;
                    height = 9;
                    width = 9;
                    break;
                case "Medium":
                    mines = 40;
                    height = 16;
                    width = 16;
                    break;
                case "Hard":
                    mines = 99;
                    height = 16;
                    width = 30;
                    break;
            }
            TableMargins(height, width);
            if (firstPlay)
            {
                StartGame();
                firstPlay = false;
            }
            else
            {
                if (!firstPlay)
                {
                    ResetGame(width, height);
                    StartGame();
                }
            }
        }

        private void MinutesBox_Click(object sender, EventArgs e)
        {
            minutesBox.Text = minutes.ToString();
        }

        private void SecondsBox_Click(object sender, EventArgs e)
        {
            secondsBox.Text = seconds.ToString();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            seconds++;
            if (seconds == 60)
            {
                minutes++;
                seconds = 0;
            }
            secondsBox.Text = seconds.ToString();
            minutesBox.Text = minutes.ToString();
        }
    }
}
