﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Author: Samantha Krall
// CST-227
// 2018

namespace Minesweeper
{
    public class PlayerStats : IComparable<PlayerStats>
    {
        public string Initials { get; set; }
        public string Difficulty { get; set; }
        public int Time { get; set; }

        public PlayerStats(string Initials, string Difficulty, int Time)
        {
            this.Initials = Initials;
            this.Difficulty = Difficulty;
            this.Time = Time;
        }
        public int CompareTo(PlayerStats other)
        {
            return Time.CompareTo(other.Time);
        }
    }
}
