﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//Author: Samantha Krall
// CST-227
// 2018

namespace Minesweeper
{
    public partial class HighScoreForm : Form
    {
        public string difficulty;
        public int score;
        public bool win;
        public List<PlayerStats> easy = new List<PlayerStats>();
        public List<PlayerStats> medium = new List<PlayerStats>();
        public List<PlayerStats> hard = new List<PlayerStats>();
        
        public HighScoreForm()
        {
            InitializeComponent();
        }
        public HighScoreForm(int difficulty, int score, bool win)
        {
            foreach(string line in File.ReadLines("highscore.csv"))
            {
                var values = line.Split(',');
                if(values[1] == "easy")
                {
                    easy.Add(new PlayerStats(values[0], values[1], System.Convert.ToInt32(values[2])));
                }
                else if (values[1] == "medium")
                {
                    medium.Add(new PlayerStats(values[0], values[1], System.Convert.ToInt32(values[2])));
                }
                else if (values[1] == "hard")
                {
                    hard.Add(new PlayerStats(values[0], values[1], System.Convert.ToInt32(values[2])));
                }
            }
            if (difficulty == 1)
            {
                this.difficulty = "easy";
            }
            else if (difficulty == 2)
            {
                this.difficulty = "medium";
            }
            else if(difficulty == 3)
            {
                this.difficulty = "hard";
            }
            this.score = score;
            this.win = win;
            InitializeComponent();
        }
        private void HighScoreForm_Load(object sender, EventArgs e)
        {
            if (!win)
            {
                initialsTextBox.Visible = false;
                highScoreButton.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                yourScoreLabel.Visible = false;
            }
            else
            {
                initialsTextBox.Visible = true;
                highScoreButton.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                yourScoreLabel.Visible = true;
                yourScoreLabel.Text = score.ToString();
            }
            string output = "Difficutly: " + difficulty + Environment.NewLine;
            if (difficulty == "easy")
            {
                foreach(var stat in easy)
                {
                    output += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            else if (difficulty == "medium")
            {
                foreach(var stat in medium)
                {
                    output += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            else if (difficulty == "hard")
            {
                foreach(var stat in hard)
                {
                    output += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            highScoreLabel.Text = output.ToUpper();
            this.CenterToScreen();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void highScoreButton_Click(object sender, EventArgs e)
        {
            if (difficulty == "easy")
            {
                easy[4] = new PlayerStats(initialsTextBox.Text, difficulty, score);
                var newList = easy.OrderByDescending(PlayerStats => PlayerStats.Time).ToList();
                for (var i = 0; i >= 4; i++)
                {
                    easy[i] = newList[i];
                }
            }
            else if (difficulty == "medium")
            {
                medium[4] = new PlayerStats(initialsTextBox.Text, difficulty, score);
                var newList = medium.OrderByDescending(PlayerStats => PlayerStats.Time).ToList();
                for(var i = 0; i >= 4; i++)
                {
                    medium[i] = newList[i];
                }
            }
            else if (difficulty == "hard")
            {
                hard[4] = new PlayerStats(initialsTextBox.Text, difficulty, score);
                var newList = hard.OrderByDescending(PlayerStats => PlayerStats.Time).ToList();
                for(var i = 0; i >= 4; i++)
                {
                    hard[i] = newList[i];
                }
            }
            if (!File.Exists("highscore.csv"))
            {
                File.Create("highscore.csv").Close();
            }
            string delimeter = ",";
            List<string[]> output = new List<string[]>();
            for(var i = 0; i < 5; i++)
            {
                output.Add(new string[] { easy[i].Initials, easy[i].Difficulty, Convert.ToString(easy[i].Time) });
            }
            for(var i = 0; i < 5; i++)
            {
                output.Add(new string[] { medium[i].Initials, medium[i].Difficulty, Convert.ToString(medium[i].Time) });
            }
            for(var i = 0; i < 5; i++)
            {
                output.Add(new string[] { hard[i].Initials, hard[i].Difficulty, Convert.ToString(hard[i].Time) });
            }
            int length = output.Count;
            using(System.IO.TextWriter writer = File.CreateText("highscore.csv"))
            {
                for(int index = 0; index < length; index++)
                {
                    writer.WriteLine(string.Join(delimeter, output[index]));
                }
            }
            string newScore = "Difficulty: " + difficulty + Environment.NewLine;
            if (difficulty == "easy")
            {
                foreach(var stat in easy)
                {
                    newScore += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            else if (difficulty == "medium")
            {
                foreach(var stat in medium)
                {
                    newScore += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            else if (difficulty == "hard")
            {
                foreach(var stat in hard)
                {
                    newScore += stat.Initials + ": " + stat.Time + Environment.NewLine;
                }
            }
            highScoreLabel.Text = newScore.ToUpper();
            initialsTextBox.Visible = false;
            highScoreButton.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            yourScoreLabel.Visible = false;
        }
    }
}
