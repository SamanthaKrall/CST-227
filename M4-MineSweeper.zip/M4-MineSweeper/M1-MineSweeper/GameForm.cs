﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1_MineSweeper
{
    public partial class GameForm : Form
    {
        

        public GameForm()
        {
            InitializeComponent();
        }

        private void easyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Board easyBoard = new EasyBoard();
        }

        private void mediumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Board mediumBoard = new MediumBoard();
        }

        private void hardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Board hardBoard = new HardBoard();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gameInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Author: Samantha Krall \nCreated in 2018 \nGrand Canyon University");
        }


        private void GameForm_Load(object sender, EventArgs e)
        {
            
        }
        

        private void timerLabel_Click(object sender, EventArgs e)
        {

        }

        private void flagsLabel_Click(object sender, EventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
