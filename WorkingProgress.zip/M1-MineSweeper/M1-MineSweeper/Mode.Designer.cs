﻿namespace M1_MineSweeper
{
    partial class Mode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mode));
            this.modeEnter = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.modeLabel = new System.Windows.Forms.Label();
            this.easyRadioButton = new System.Windows.Forms.RadioButton();
            this.mediumRadioButton = new System.Windows.Forms.RadioButton();
            this.hardRadioButton = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // modeEnter
            // 
            this.modeEnter.Location = new System.Drawing.Point(29, 191);
            this.modeEnter.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.modeEnter.Name = "modeEnter";
            this.modeEnter.Size = new System.Drawing.Size(163, 42);
            this.modeEnter.TabIndex = 0;
            this.modeEnter.Text = "&Play Game";
            this.modeEnter.UseVisualStyleBackColor = true;
            this.modeEnter.Click += new System.EventHandler(this.modeEnter_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(29, 245);
            this.exitButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(163, 42);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // modeLabel
            // 
            this.modeLabel.AutoSize = true;
            this.modeLabel.Location = new System.Drawing.Point(25, 18);
            this.modeLabel.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.modeLabel.Name = "modeLabel";
            this.modeLabel.Size = new System.Drawing.Size(259, 24);
            this.modeLabel.TabIndex = 4;
            this.modeLabel.Text = "Choose your diffuculty:";
            this.modeLabel.Click += new System.EventHandler(this.modeLabel_Click);
            // 
            // easyRadioButton
            // 
            this.easyRadioButton.AutoSize = true;
            this.easyRadioButton.Location = new System.Drawing.Point(29, 58);
            this.easyRadioButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.easyRadioButton.Name = "easyRadioButton";
            this.easyRadioButton.Size = new System.Drawing.Size(84, 28);
            this.easyRadioButton.TabIndex = 5;
            this.easyRadioButton.TabStop = true;
            this.easyRadioButton.Text = "Easy ";
            this.easyRadioButton.UseVisualStyleBackColor = true;
            // 
            // mediumRadioButton
            // 
            this.mediumRadioButton.AutoSize = true;
            this.mediumRadioButton.Location = new System.Drawing.Point(29, 102);
            this.mediumRadioButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.mediumRadioButton.Name = "mediumRadioButton";
            this.mediumRadioButton.Size = new System.Drawing.Size(109, 28);
            this.mediumRadioButton.TabIndex = 6;
            this.mediumRadioButton.TabStop = true;
            this.mediumRadioButton.Text = "Medium";
            this.mediumRadioButton.UseVisualStyleBackColor = true;
            this.mediumRadioButton.CheckedChanged += new System.EventHandler(this.mediumRadioButton_CheckedChanged);
            // 
            // hardRadioButton
            // 
            this.hardRadioButton.AutoSize = true;
            this.hardRadioButton.Location = new System.Drawing.Point(29, 151);
            this.hardRadioButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.hardRadioButton.Name = "hardRadioButton";
            this.hardRadioButton.Size = new System.Drawing.Size(77, 28);
            this.hardRadioButton.TabIndex = 7;
            this.hardRadioButton.TabStop = true;
            this.hardRadioButton.Text = "Hard";
            this.hardRadioButton.UseVisualStyleBackColor = true;
            // 
            // Mode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(300, 300);
            this.Controls.Add(this.hardRadioButton);
            this.Controls.Add(this.mediumRadioButton);
            this.Controls.Add(this.easyRadioButton);
            this.Controls.Add(this.modeLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.modeEnter);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Name = "Mode";
            this.Text = "Minesweeper";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button modeEnter;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label modeLabel;
        private System.Windows.Forms.RadioButton easyRadioButton;
        private System.Windows.Forms.RadioButton mediumRadioButton;
        private System.Windows.Forms.RadioButton hardRadioButton;
    }
}