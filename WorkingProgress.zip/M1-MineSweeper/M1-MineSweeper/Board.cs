﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    
     public class Board
     {
        public Cell[,] cellArray;
        //private string title;
        private int horizontal;
        private int vertical;
        private int totalMines;
        //private bool twoDigitYAxis;
        //private bool twoDigitXAxis;
        private GameState state;
        public Board()
        {
            State = GameState.BlankGameBoard;
        }
        public void WriteBoard()
        {
            int selectableCells = Horizontal * Vertical;
            for(int y = 0; y < Vertical; y++)
                //checks through y values from top to bottom
            {
                WriteYCoordinate(y);
                for(int x = 0; x < Horizontal; x++)
                    //checks through x values from left to right
                {
                    Cell cell = CellArray[y, x];
                    
                    if (cell.IsFlagged)
                    {
                        
                        //Program.PrintColoredString("F", ConsoleColor.DarkRed);
                    }
                    else if (!cell.IsSelected)
                    {
                        //Program.PrintColoredString("#", ConsoleColor.DarkGray);
                    }
                    else if (cell.IsMine)
                    {
                        //Program.PrintColoredString("X", ConsoleColor.DarkRed);
                        State = GameState.MineSelected;
                    }
                    else
                    {
                        WriteColoredSurroundingMinesValue(cell.SurroundingMinesValue);
                        selectableCells--;
                    }
                    //if (twoDigitXAxis)
                    //{
                      //  Console.Write("   ");
                    //}
                    //else
                    //{
                      //  Console.Write("  ");
                    //}
                }
                //Console.WriteLine();
            }
            WriteXCoordinates();
            if(selectableCells == TotalMines && State != GameState.MineSelected)
                //checks if game has been won
            {
                State = GameState.GameWon;
            }
        }
        public void SelectCell(int y, int x)
        {
            Cell selectedCell = CellArray[y, x];
            if(selectedCell.IsSelected || selectedCell.IsFlagged)
                return;
            selectedCell.IsSelected = true;
            if(State == GameState.BlankGameBoard)
            {
                GenerateMines(y, x);
                State = GameState.GameInProgress;
            }
            if(selectedCell.SurroundingMinesValue == 0)
            {
                RevealAroundConnectingZeros(y, x);
            }
        }
        public void FlagCell(int y, int x)
        {
            Cell flaggedCell = CellArray[y, x];
            if (flaggedCell.IsSelected)
            {
                return;
            }
            flaggedCell.IsFlagged = !flaggedCell.IsFlagged;
        }
        private void RevealAroundConnectingZeros(int yInput, int xInput)
        {
            CellArray[yInput, xInput].SurroundingMinesChecked = true;
            for(int y = yInput -1; y <= yInput + 1; y++)
            {
                if(y < 0 || y >= Vertical)
                {
                    continue;
                }
                for(int x = xInput -1; x <= xInput + 1; x++)
                {
                    if(x < 0 || x >= Horizontal)
                    {
                        continue;
                    }
                    CellArray[y, x].IsSelected = true;
                    if(CellArray[y,x].SurroundingMinesValue == 0 && !CellArray[y, x].SurroundingMinesChecked)
                    {
                        WriteColoredSurroundingMinesValue(CountSurroundingMines(y, x));
                        RevealAroundConnectingZeros(y, x);
                    }
                }
            }
        }
        private void GenerateMines(int y, int x)
        {
            BlacklistSurroundingCells(y, x);
            Random rnd = new Random();
            for(int i = 0; i < TotalMines; i++)
            {
                int yRndValue = rnd.Next(Vertical);
                int xRndValue = rnd.Next(Horizontal);
                Cell randomCell = CellArray[yRndValue, xRndValue];
                if(randomCell.IsMineBlacklisted || randomCell.IsMine || randomCell.IsSelected)
                {
                    i--;
                }
                else
                {
                    randomCell.IsMine = true;
                }
            }
            GenerateSurroundMinesValues();
        }
        protected void CreateEmptyCellArray()
        {
            CellArray = new Cell[Vertical, Horizontal];            
            for(int y = 0; y < Vertical; y++)
            {
                for(int x = 0; x < Horizontal; x++)
                {
                    CellArray[y, x] = new Cell();
                }
            }
        }
        private void BlacklistSurroundingCells(int yInput, int xInput)
        {
            for(int y = yInput - 1; y <= yInput + 1; y++)
            {
                if(y < 0 || y >= Vertical)
                {
                    continue;
                }
                for(int x = xInput - 1; x <= xInput + 1; x++)
                {
                    if(x < 0 || x >= Horizontal)
                    {
                        continue;
                    }
                    CellArray[y, x].IsMineBlacklisted = true;
                }
            }
        }
        private void GenerateSurroundMinesValues()
        {
            for(int y = 0; y < Vertical; y++)
            {
                for(int x = 0; x < Horizontal; x++)
                {
                    CellArray[y, x].SurroundingMinesValue = CountSurroundingMines(y, x);
                }
            }
        }
        private int CountSurroundingMines(int yInput, int xInput)
        {
            int surroundingMinesValue = 0;
            for(int y = yInput -1; y <= yInput + 1; y++)
            {
                if(y < 0 || y >= Vertical)
                {
                    continue;
                }
                for(int x = xInput - 1; x <= xInput + 1; x++)
                {
                    if(x < 0 || x >= Horizontal || !CellArray[y, x].IsMine)
                    {
                        continue;
                    }
                    surroundingMinesValue++;
                }
            }
            return surroundingMinesValue;
        }
        private void WriteYCoordinate(int y)
        {
            int yValue = Vertical - y;
            //Console.WriteLine(yValue + " ");
            //if(twoDigitYAxis && yValue <= 9)
            //{
              //  Console.Write(" ");
            //}
        }
        private void WriteXCoordinates()
        {
            //Console.Write("  ");
            //if (twoDigitYAxis)
              //  Console.Write(" ");
            for(int i = 0; i < Horizontal; i++)
            {
                //Console.Write(i + 1 + " ");
                //if (twoDigitXAxis && i + 1 < 10)
                  //  Console.Write(" ");
            }
            //Console.WriteLine();
        }
        private void WriteColoredSurroundingMinesValue(int number)
        {
            switch (number)
            {
                case 0:
                    Console.Write(" ");
                    break;
                case 1:
                    //Program.PrintColoredString("1", ConsoleColor.DarkBlue);
                    break;
                case 2:
                    //Program.PrintColoredString("2", ConsoleColor.DarkBlue);
                    break;
                case 3:
                    //Program.PrintColoredString("3", ConsoleColor.DarkBlue);
                    break;
                case 4:
                    //Program.PrintColoredString("4", ConsoleColor.DarkBlue);
                    break;
                case 5:
                    //Program.PrintColoredString("5", ConsoleColor.DarkBlue);
                    break;
                case 6:
                    //Program.PrintColoredString("6", ConsoleColor.DarkBlue);
                    break;
                case 7:
                    //Program.PrintColoredString("7", ConsoleColor.DarkBlue);
                    break;
                case 8:
                    //Program.PrintColoredString("8", ConsoleColor.DarkBlue);
                    break;
                default:
                    break;
            }
        }
        public enum GameState
        {
            BlankGameBoard, 
            GameInProgress,
            MineSelected,
            GameWon
        }
        public Cell[,] CellArray { get => cellArray; set => cellArray = value; }
        //public string Title { get => title; set => title = value; }
        public int Horizontal { get => horizontal; set => horizontal = value; }
        public int Vertical { get => vertical; set => vertical = value; }
        public int TotalMines { get => totalMines; set => totalMines = value; }
        //protected bool TwoDigitYAxis { get => twoDigitYAxis; set => twoDigitYAxis = value; }
        //protected bool TwoDigitXAxis { get => twoDigitXAxis; set => twoDigitXAxis = value; }
        public GameState State { get => state; set => state = value; }
    }
}
