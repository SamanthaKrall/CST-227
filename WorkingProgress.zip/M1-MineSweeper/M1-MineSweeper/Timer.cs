﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    class Timer
    {
        public Action<object, ElapsedEventArgs> Elapsed { get; internal set; }
    }
}
