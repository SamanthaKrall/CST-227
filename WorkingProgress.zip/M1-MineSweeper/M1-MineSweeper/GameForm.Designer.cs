﻿namespace M1_MineSweeper
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.easyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mediumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gameInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.timerLabel = new System.Windows.Forms.Label();
            this.flagsLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(442, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.easyToolStripMenuItem,
            this.mediumToolStripMenuItem,
            this.hardToolStripMenuItem});
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // easyToolStripMenuItem
            // 
            this.easyToolStripMenuItem.Name = "easyToolStripMenuItem";
            this.easyToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.easyToolStripMenuItem.Text = "Easy";
            this.easyToolStripMenuItem.Click += new System.EventHandler(this.easyToolStripMenuItem_Click);
            // 
            // mediumToolStripMenuItem
            // 
            this.mediumToolStripMenuItem.Name = "mediumToolStripMenuItem";
            this.mediumToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.mediumToolStripMenuItem.Text = "Medium";
            this.mediumToolStripMenuItem.Click += new System.EventHandler(this.mediumToolStripMenuItem_Click);
            // 
            // hardToolStripMenuItem
            // 
            this.hardToolStripMenuItem.Name = "hardToolStripMenuItem";
            this.hardToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.hardToolStripMenuItem.Text = "Hard";
            this.hardToolStripMenuItem.Click += new System.EventHandler(this.hardToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(95, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameInformationToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // gameInformationToolStripMenuItem
            // 
            this.gameInformationToolStripMenuItem.Name = "gameInformationToolStripMenuItem";
            this.gameInformationToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.gameInformationToolStripMenuItem.Text = "Game Information";
            this.gameInformationToolStripMenuItem.Click += new System.EventHandler(this.gameInformationToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(20, 20);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(38, 39);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(20, 20);
            this.button2.TabIndex = 2;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(64, 39);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(20, 20);
            this.button3.TabIndex = 3;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(90, 39);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(20, 20);
            this.button4.TabIndex = 4;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(116, 39);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(20, 20);
            this.button5.TabIndex = 5;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(142, 39);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(20, 20);
            this.button6.TabIndex = 6;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(168, 39);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(20, 20);
            this.button7.TabIndex = 7;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(194, 39);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(20, 20);
            this.button8.TabIndex = 8;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(220, 39);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(20, 20);
            this.button9.TabIndex = 9;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 65);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(20, 20);
            this.button10.TabIndex = 10;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(275, 258);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(0, 0);
            this.button11.TabIndex = 11;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(64, 65);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(20, 20);
            this.button12.TabIndex = 12;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(90, 65);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(20, 20);
            this.button13.TabIndex = 13;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(116, 65);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(20, 20);
            this.button14.TabIndex = 14;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(142, 65);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(20, 20);
            this.button15.TabIndex = 15;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(168, 65);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(20, 20);
            this.button16.TabIndex = 16;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(194, 65);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(20, 20);
            this.button17.TabIndex = 17;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(220, 65);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(20, 20);
            this.button18.TabIndex = 18;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(12, 91);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(20, 20);
            this.button19.TabIndex = 19;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(38, 91);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(20, 20);
            this.button20.TabIndex = 20;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(38, 65);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(20, 20);
            this.button21.TabIndex = 21;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(64, 91);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(20, 20);
            this.button22.TabIndex = 22;
            this.button22.Text = "button22";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(116, 91);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(20, 20);
            this.button23.TabIndex = 23;
            this.button23.Text = "button23";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(227, 210);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(0, 0);
            this.button24.TabIndex = 24;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(142, 91);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(20, 20);
            this.button25.TabIndex = 25;
            this.button25.Text = "button25";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(168, 91);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(20, 20);
            this.button26.TabIndex = 26;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(243, 226);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(0, 0);
            this.button27.TabIndex = 27;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(194, 91);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(20, 20);
            this.button28.TabIndex = 28;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(220, 91);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(20, 20);
            this.button29.TabIndex = 29;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(12, 117);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(20, 20);
            this.button30.TabIndex = 30;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(38, 117);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(20, 20);
            this.button31.TabIndex = 31;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(90, 91);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(20, 20);
            this.button32.TabIndex = 32;
            this.button32.Text = "button32";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(64, 117);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(20, 20);
            this.button33.TabIndex = 33;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(90, 117);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(20, 20);
            this.button34.TabIndex = 34;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(116, 117);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(20, 20);
            this.button35.TabIndex = 35;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(235, 218);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(0, 0);
            this.button36.TabIndex = 36;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(142, 117);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(20, 20);
            this.button37.TabIndex = 37;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(168, 117);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(20, 20);
            this.button38.TabIndex = 38;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(227, 210);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(0, 0);
            this.button39.TabIndex = 39;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(194, 117);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(20, 20);
            this.button40.TabIndex = 40;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(220, 117);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(20, 20);
            this.button41.TabIndex = 41;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(12, 143);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(20, 20);
            this.button42.TabIndex = 42;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(38, 143);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(20, 20);
            this.button43.TabIndex = 43;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(64, 143);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(20, 20);
            this.button44.TabIndex = 44;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(90, 143);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(20, 20);
            this.button45.TabIndex = 45;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(243, 226);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(0, 0);
            this.button46.TabIndex = 46;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(116, 143);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(20, 20);
            this.button47.TabIndex = 47;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(142, 143);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(20, 20);
            this.button48.TabIndex = 48;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(168, 143);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(20, 20);
            this.button49.TabIndex = 49;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(194, 143);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(20, 20);
            this.button50.TabIndex = 50;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(220, 143);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(20, 20);
            this.button51.TabIndex = 51;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(12, 169);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(20, 20);
            this.button52.TabIndex = 52;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(38, 169);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(20, 20);
            this.button53.TabIndex = 53;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(64, 169);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(20, 20);
            this.button54.TabIndex = 54;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(90, 169);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(20, 20);
            this.button55.TabIndex = 55;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(116, 169);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(20, 20);
            this.button56.TabIndex = 56;
            this.button56.Text = "button56";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(142, 169);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(20, 20);
            this.button57.TabIndex = 57;
            this.button57.Text = "button57";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(168, 169);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(20, 20);
            this.button58.TabIndex = 58;
            this.button58.Text = "button58";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(194, 169);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(20, 20);
            this.button59.TabIndex = 59;
            this.button59.Text = "button59";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(220, 169);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(20, 20);
            this.button60.TabIndex = 60;
            this.button60.Text = "button60";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(12, 195);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(20, 20);
            this.button61.TabIndex = 61;
            this.button61.Text = "button61";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(38, 195);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(20, 20);
            this.button62.TabIndex = 62;
            this.button62.Text = "button62";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(64, 195);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(20, 20);
            this.button63.TabIndex = 63;
            this.button63.Text = "button63";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(90, 195);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(20, 20);
            this.button64.TabIndex = 64;
            this.button64.Text = "button64";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(116, 195);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(20, 20);
            this.button65.TabIndex = 65;
            this.button65.Text = "button65";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(142, 195);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(20, 20);
            this.button66.TabIndex = 66;
            this.button66.Text = "button66";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(168, 195);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(20, 20);
            this.button67.TabIndex = 67;
            this.button67.Text = "button67";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(194, 195);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(20, 20);
            this.button68.TabIndex = 68;
            this.button68.Text = "button68";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(220, 195);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(20, 20);
            this.button69.TabIndex = 69;
            this.button69.Text = "button69";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(12, 221);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(20, 20);
            this.button70.TabIndex = 70;
            this.button70.Text = "button70";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(38, 221);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(20, 20);
            this.button71.TabIndex = 71;
            this.button71.Text = "button71";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(64, 221);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(20, 20);
            this.button72.TabIndex = 72;
            this.button72.Text = "button72";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(90, 221);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(20, 20);
            this.button73.TabIndex = 73;
            this.button73.Text = "button73";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(116, 221);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(20, 20);
            this.button74.TabIndex = 74;
            this.button74.Text = "button74";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(142, 221);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(20, 20);
            this.button75.TabIndex = 75;
            this.button75.Text = "button75";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(168, 221);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(20, 20);
            this.button76.TabIndex = 76;
            this.button76.Text = "button76";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(194, 221);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(20, 20);
            this.button77.TabIndex = 77;
            this.button77.Text = "button77";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(220, 221);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(20, 20);
            this.button78.TabIndex = 78;
            this.button78.Text = "button78";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(12, 247);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(20, 20);
            this.button79.TabIndex = 79;
            this.button79.Text = "button79";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(38, 248);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(20, 20);
            this.button80.TabIndex = 80;
            this.button80.Text = "button80";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(64, 247);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(20, 20);
            this.button81.TabIndex = 81;
            this.button81.Text = "button81";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(90, 247);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(20, 20);
            this.button82.TabIndex = 82;
            this.button82.Text = "button82";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(116, 247);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(20, 20);
            this.button83.TabIndex = 83;
            this.button83.Text = "button83";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(142, 247);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(20, 20);
            this.button84.TabIndex = 84;
            this.button84.Text = "button84";
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(168, 247);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(20, 20);
            this.button85.TabIndex = 85;
            this.button85.Text = "button85";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(194, 247);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(20, 20);
            this.button86.TabIndex = 86;
            this.button86.Text = "button86";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(220, 247);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(20, 20);
            this.button87.TabIndex = 87;
            this.button87.Text = "button87";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // timerLabel
            // 
            this.timerLabel.AutoSize = true;
            this.timerLabel.Location = new System.Drawing.Point(31, 297);
            this.timerLabel.Name = "timerLabel";
            this.timerLabel.Size = new System.Drawing.Size(35, 13);
            this.timerLabel.TabIndex = 88;
            this.timerLabel.Text = "label1";
            this.timerLabel.Click += new System.EventHandler(this.timerLabel_Click);
            // 
            // flagsLabel
            // 
            this.flagsLabel.AutoSize = true;
            this.flagsLabel.Location = new System.Drawing.Point(31, 333);
            this.flagsLabel.Name = "flagsLabel";
            this.flagsLabel.Size = new System.Drawing.Size(35, 13);
            this.flagsLabel.TabIndex = 89;
            this.flagsLabel.Text = "label1";
            this.flagsLabel.Click += new System.EventHandler(this.flagsLabel_Click);
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 408);
            this.Controls.Add(this.flagsLabel);
            this.Controls.Add(this.timerLabel);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GameForm";
            this.Text = "GameForm";
            this.Load += new System.EventHandler(this.GameForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem easyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mediumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hardToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gameInformationToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Label timerLabel;
        private System.Windows.Forms.Label flagsLabel;
    }
}