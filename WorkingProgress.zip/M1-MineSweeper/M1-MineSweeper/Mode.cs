﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1_MineSweeper
{
    public partial class Mode : Form
    {
        public Mode()
        {
            InitializeComponent();
        }

        private void mediumRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void modeEnter_Click(object sender, EventArgs e)
        {
            
            if (easyRadioButton.Checked)
            {
                this.Hide();
                GameForm gameForm = new GameForm();
                Board easyBoard = new EasyBoard();
                gameForm.ShowDialog();
            }
            else if (mediumRadioButton.Checked)
            {
                
            }
            else if (hardRadioButton.Checked)
            {
               
            }
            else
            {
                
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void modeLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
