﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    class Program 
    {
        static void Main(string[] args)
        {
            Console.Title = "Minsweeper";
            Console.BackgroundColor = ConsoleColor.Gray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);
            Console.SetWindowPosition(0, 0);
            Console.WriteLine("Welcome to Console Minesweeper!\n");
            bool run = true;
            while (run)
            {
                Board currentBoard = GetGameMode();
                PlayGame(currentBoard);
                if (!ContinueGame())
                    run = false;
            }
        }
        public static Board GetGameMode()
        {
            Console.WriteLine("Please select a game mode:");
            Console.WriteLine("1. Easy Mode");
            Console.WriteLine("2. Medium Mode");
            Console.WriteLine("3. Hard Mode");
            Console.WriteLine("4. Custom Mode");
            int menuOptionInput = ConsoleValidation.GetIntegerInRange(1, 4);
            switch (menuOptionInput)
            {
                case 1:
                    Board easyBoard = new EasyBoard();
                    return easyBoard;
                case 2:
                    Board mediumBoard = new MediumBoard();
                    return mediumBoard;
                case 3:
                    Board hardBoard = new HardBoard();
                    return hardBoard;
                default:
                    Console.Write("Horizontal size (5-30): ");
                    int customHorizontalInput = ConsoleValidation.GetIntegerInRange(5, 30);
                    Console.Write("Vertical size (5-30): ");
                    int customVerticalInput = ConsoleValidation.GetIntegerInRange(5, 30);
                    int customBoardArea = customHorizontalInput * customVerticalInput;
                    Console.WriteLine($"Amount of mines (1-{customBoardArea - 9}):");
                    int customMinesInput = ConsoleValidation.GetIntegerInRange(1, customBoardArea - 9);
                    Board customBoard = new CustomBoard(customHorizontalInput, customVerticalInput, customMinesInput);
                    return customBoard;
            }
        }
        public static void PlayGame(Board currentBoard)
        {
            bool runGame = true;
            while (runGame)
            {
                Console.Clear();
                Console.WriteLine($"{currentBoard.Title} Mode - {currentBoard.TotalMines} mines");
                currentBoard.WriteBoard();
                if(currentBoard.State == Board.GameState.MineSelected)
                {
                    Console.WriteLine("Game over... You hit a Mine!");
                    return;
                }
                else if(currentBoard.State == Board.GameState.GameWon)
                {
                    Console.WriteLine("You won!");
                    return;
                }
                Console.WriteLine("Type a coordinate followed by a space and  S or F to select or flag");
                Console.WriteLine("For example: Enter '1/3 S' ");
                InputCoordinates coordinates = ConsoleValidation.GetValidCoordinates(currentBoard.Vertical, currentBoard.Horizontal);
                int yCoord = currentBoard.Vertical - coordinates.Y;
                int xCoord = coordinates.X - 1;
                if(coordinates.Option == SelectOrFlag.S)
                {
                    currentBoard.SelectCell(yCoord, xCoord);
                }else if(coordinates.Option == SelectOrFlag.F)
                {
                    currentBoard.FlagCell(yCoord, xCoord);
                }
            }
        }
        public static bool ContinueGame()
        {
            Console.Write("Would you like to play again?(y/n): ");
            string input = ConsoleValidation.GetValidString(new string[] { "y", "n" });
            if(input == "y")
            {
                Console.Clear();
                return true;
            }
            else
            {
                return false;
            }
        }
        public static void PrintColoredString(string stringValue, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.Write(stringValue);
            Console.ForegroundColor = ConsoleColor.Black;
        }

        public void PlayGame()
        {
            throw new NotImplementedException();
        }
    }
}
