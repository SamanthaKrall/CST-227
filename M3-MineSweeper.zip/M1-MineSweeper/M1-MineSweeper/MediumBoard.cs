﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    class MediumBoard : Board
    {
        public MediumBoard() : base()
        {
            Title = "Medium";
            Horizontal = 16;
            Vertical = 16;
            TwoDigitYAxis = true;
            TwoDigitXAxis = true;
            TotalMines = 40;
            CreateEmptyCellArray();
        }
    }
}
