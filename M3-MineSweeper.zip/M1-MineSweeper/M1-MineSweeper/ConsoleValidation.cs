﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    class ConsoleValidation
    {
        public static string GetValidString(string [] options)
        {
            string input;
            string listOfOptions = string.Join(",", options);
            while (true)
            {
                input = Console.ReadLine().Trim().ToLower();
                foreach(string item in options)
                {
                    if(input == item)
                        return input;
                }
                Program.PrintColoredString($"Input must be either of the following: [{listOfOptions}]. Try again.\n", ConsoleColor.DarkRed);
            }
        }
        public static int GetValidInteger()
        {
            int input;
            while(!int.TryParse(Console.ReadLine(), out input))
            {
                Program.PrintColoredString("Invalid input. Please try again.\n", ConsoleColor.DarkRed);
            }
            return input;
        }
        public static int GetIntegerInRange(int min, int max)
        {
            int input = GetValidInteger();
            while(input < min || input > max)
            {
                Program.PrintColoredString($"Input is not between {min} and {max}. Please try again.\n", ConsoleColor.DarkRed);
                input = GetValidInteger();
            }
            return input;
        }
        public static InputCoordinates GetValidCoordinates(int vertical, int horizontal)
        {
            while (true)
            {
                string input = Console.ReadLine().Trim().ToLower();
                string[] values;
                // check that user input is 0-30, either \/, 0-30, space and either s or f 
                if ( !Regex.IsMatch(input, @"([0-9]|[1-2][0-9]|30)\/([0-9]|[1-2][0-9]|30)\s[sf]"))
                {
                    Program.PrintColoredString("Invalid input. Enter an int between 0-30. Please try again\n", ConsoleColor.DarkRed);
                    continue;
                }
                values = input.Split(new char[] { '/', ' ' });
                if(!int.TryParse(values[0], out int x))
                {
                    Program.PrintColoredString("Invalid x input. Please try again\n", ConsoleColor.DarkRed);
                    continue;
                }
                if(!int.TryParse(values[1],out int y))
                {
                    Program.PrintColoredString("Invalid y input. Please try again\n", ConsoleColor.DarkRed);
                    continue;
                }
                if(x < 1 || x > horizontal)
                {
                    Program.PrintColoredString($"X is not between 1 and {horizontal}\n", ConsoleColor.DarkRed);
                    continue;
                }
                if(y < 1 || y > vertical)
                {
                    Program.PrintColoredString($"Y is not between 1 and {vertical}\n", ConsoleColor.DarkRed);
                    continue;
                }
                if(!Enum.TryParse(values[2].ToUpper() ,out SelectOrFlag option))
                {
                    Program.PrintColoredString($"Action is not S or F. Please try again\n", ConsoleColor.DarkRed);
                    continue;
                }
                return new InputCoordinates(y, x, option);
            }
        }
    }
}
