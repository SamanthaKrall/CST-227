﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Author: Samantha Krall
 * CST 227
 * Milestone3- Minesweeper
 * */

namespace M1_MineSweeper
{
    class EasyBoard : Board
    {
        public EasyBoard() : base()
        {
            Title = "Easy";
            Horizontal = 9;
            Vertical = 9;
            TwoDigitYAxis = false;
            TwoDigitXAxis = false;
            TotalMines = 10;
            CreateEmptyCellArray();
        }
    }
}
