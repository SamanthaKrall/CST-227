﻿namespace Minesweeper
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.score = new System.Windows.Forms.Label();
            this.remainingFlags = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.Play = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.difficultyCB = new System.Windows.Forms.ComboBox();
            this.minutesBox = new System.Windows.Forms.Label();
            this.secondsBox = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.score.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.score.ForeColor = System.Drawing.Color.Red;
            this.score.Location = new System.Drawing.Point(31, 416);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(70, 27);
            this.score.TabIndex = 0;
            this.score.Text = "Score";
            // 
            // remainingFlags
            // 
            this.remainingFlags.AutoSize = true;
            this.remainingFlags.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.remainingFlags.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.remainingFlags.ForeColor = System.Drawing.Color.Red;
            this.remainingFlags.Location = new System.Drawing.Point(204, 416);
            this.remainingFlags.Name = "remainingFlags";
            this.remainingFlags.Size = new System.Drawing.Size(67, 27);
            this.remainingFlags.TabIndex = 1;
            this.remainingFlags.Text = "Flags";
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.time.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.time.ForeColor = System.Drawing.Color.Red;
            this.time.Location = new System.Drawing.Point(384, 416);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(61, 27);
            this.time.TabIndex = 2;
            this.time.Text = "Time";
            // 
            // Play
            // 
            this.Play.Location = new System.Drawing.Point(304, 12);
            this.Play.Name = "Play";
            this.Play.Size = new System.Drawing.Size(237, 35);
            this.Play.TabIndex = 3;
            this.Play.Text = "&Play";
            this.Play.UseVisualStyleBackColor = true;
            this.Play.Click += new System.EventHandler(this.Play_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(494, 413);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = ":";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // difficultyCB
            // 
            this.difficultyCB.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.difficultyCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.difficultyCB.FormattingEnabled = true;
            this.difficultyCB.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.difficultyCB.Location = new System.Drawing.Point(31, 14);
            this.difficultyCB.Name = "difficultyCB";
            this.difficultyCB.Size = new System.Drawing.Size(204, 33);
            this.difficultyCB.TabIndex = 7;
            // 
            // minutesBox
            // 
            this.minutesBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.minutesBox.ForeColor = System.Drawing.Color.Red;
            this.minutesBox.Location = new System.Drawing.Point(460, 416);
            this.minutesBox.Name = "minutesBox";
            this.minutesBox.Size = new System.Drawing.Size(36, 27);
            this.minutesBox.TabIndex = 8;
            this.minutesBox.Click += new System.EventHandler(this.MinutesBox_Click);
            // 
            // secondsBox
            // 
            this.secondsBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.secondsBox.ForeColor = System.Drawing.Color.Red;
            this.secondsBox.Location = new System.Drawing.Point(518, 416);
            this.secondsBox.Name = "secondsBox";
            this.secondsBox.Size = new System.Drawing.Size(36, 27);
            this.secondsBox.TabIndex = 9;
            this.secondsBox.Click += new System.EventHandler(this.SecondsBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(761, 452);
            this.Controls.Add(this.secondsBox);
            this.Controls.Add(this.minutesBox);
            this.Controls.Add(this.difficultyCB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Play);
            this.Controls.Add(this.time);
            this.Controls.Add(this.remainingFlags);
            this.Controls.Add(this.score);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Minesweeper";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Label remainingFlags;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Button Play;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer;
        public System.Windows.Forms.ComboBox difficultyCB;
        private System.Windows.Forms.Label minutesBox;
        private System.Windows.Forms.Label secondsBox;
    }
}

